#ifndef BASE64CODER_H
#define BASE64CODER_H

#include <QObject>
#include "RESTTalker.h" // Include your RESTTalker class header

class Base64Coder : public QObject
{
    Q_OBJECT

public:
    Base64Coder(RESTTalker* restTalker);
    QString encode(const QString& input);

private slots:
    void onReplyReceived();

private:
    RESTTalker* pRESTTalker;
    QString result;

    QString parseResponse(const QString& response);
};

#endif // BASE64CODER_H
